package clases;
/* 
 * Explica tu código aquí
 * 
 * @author Pablo Ruiz
 */

public interface MascotaInterface {

  public void pasear();

}